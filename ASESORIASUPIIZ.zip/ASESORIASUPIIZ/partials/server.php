<?php
$file = $_FILES["file"]["name"];

if(!is_dir("../php/imagenes/"))
	mkdir("../php/imagenes/", 0777);

if($file && move_uploaded_file($_FILES["file"]["tmp_name"], "../php/imagenes/".$file))
{
	echo $file;
}
?>
