<?php 
require('../php/conexion.php');
header("Content-Type: text/html;charset=utf-8");
session_start();
$sql1 = 'SELECT * FROM `usuarios` WHERE `usuarios`.`id_usuario`=:id';
  $resultado1=$base->prepare($sql1);
    $resultado1->bindValue(":id",$_SESSION['id']);
    $resultado1->execute();
    $nombre1= $resultado1->fetch();
    $is=false;

if ($nombre1['tipo_usuario']=="Asesor") {
  $sql = 'SELECT * FROM usuarios INNER JOIN ejercicios WHERE( usuarios.id_usuario = ejercicios.id_asesor)and (usuarios.tipo_usuario = "Administrador") and (ejercicios.modulo = 3)';
}else{
  $sql = 'SELECT * FROM `ejercicios` WHERE `ejercicios`.`modulo` = 3';
}

if ($nombre1['tipo_usuario']=="Asesorado" | $nombre1['tipo_usuario']=="Alumno Asesor") {
  $is= true;
}

$result =$base->query($sql);

    // Extract the values from $result
    $rows = $result->fetchAll();

 $a=1; 
   
foreach ($rows as $row) {  
$sql = 'SELECT * FROM `usuarios` WHERE `usuarios`.`id_usuario`=:id';
  $resultado=$base->prepare($sql);
    $resultado->bindValue(":id",$row['id_asesor']);
    $resultado->execute();
    $nombre= $resultado->fetch();

 if (!$is) {
 
  if ($a==1) {
     $a=2;
     echo '<div class="container-fluid fondo3 bordes" style="margin:2px " >
     <div class="col-md-2 fondo4 text-center bordes " style=" font-size: 80%;">
     <h3><span  style="color:#0A1248;" class="glyphicon glyphicon-book"></span></h3><br/>
         <button id="todos" name="todos" type="submit" value="todos" onclick = "location=\'../php/borrarEjercicio.php?variable1='.$row['direcion_ej'].'\'"class="btn btn-primary btn-sm" ;>Borrar</button>
          <button id="todos" name="todos" type="submit" value="todos" onclick="editar('.$row['id_ejercicios'].')" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#myModal";>Editar Nombre</button> 
           <br/>
         </div> 

     <a href=\''.$row['direcion_ej'].'\' title=\''.$row['nombre_ej'].'\' style="color:#000000;">
     <div class="col-md-10 " style=" word-wrap: break-word;">
        <div class="col-md-12 "> <h4>'.$row['nombre_ej'].'</h4></div>
       <h6> Subido por :   '.$nombre['nombre'].' '.$nombre['apellido_paterno'].' '.$nombre['apellido_materno'].'</h6> </div>
         </a></div>';

  } else{
    $a=1;
      echo '<div class="container-fluid fondo1 bordes" style="margin:2px " >
     <div class="col-md-2 fondo2 text-center bordes " style=" font-size: 80%;">
     <h3><span  style="color:#0A1248;" class="glyphicon glyphicon-book"></span></h3><br/>
      <button id="todos" name="todos" type="submit" value="todos" onclick = "location=\'../php/borrarEjercicio.php?variable1='.$row['direcion_ej'].'\'"class="btn btn-primary btn-sm" ;>Borrar</button>
      <button id="todos" name="todos" type="submit" value="todos" onclick="editar('.$row['id_ejercicios'].')" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#myModal";>Editar Nombre</button>
    </div>
        <br/> 
     <a href=\''.$row['direcion_ej'].'\' title=\''.$row['nombre_ej'].'\' style="color:#000000;">
     <div class="col-md-10 " style=" word-wrap: break-word;">
        <div class="col-md-12 "> <h4>'.$row['nombre_ej'].'</h4></div>
       <h6> Subido por :   '.$nombre['nombre'].' '.$nombre['apellido_paterno'].' '.$nombre['apellido_materno'].'</h6> </div>
         </a> </div>' ;
  }
   } else if ($is) {
    if ($a==1) {
     $a=2;
     echo '<div class="container-fluid fondo3 bordes" style="margin:2px " >
     <div class="col-md-2 fondo4 text-center bordes " style=" font-size: 80%;">
     <h3><span  style="color:#0A1248;" class="glyphicon glyphicon-book"></span></h3><br/> 
           <br/>
         </div> 

     <a href=\''.$row['direcion_ej'].'\' title=\''.$row['nombre_ej'].'\' style="color:#000000;">
     <div class="col-md-10 " style=" word-wrap: break-word;">
        <div class="col-md-12 "> <h4>'.$row['nombre_ej'].'</h4></div>
       <h6> Subido por :   '.$nombre['nombre'].' '.$nombre['apellido_paterno'].' '.$nombre['apellido_materno'].'</h6> </div>
         </a></div>';

  } else{
    $a=1;
      echo '<div class="container-fluid fondo1 bordes" style="margin:2px " >
     <div class="col-md-2 fondo2 text-center bordes " style=" font-size: 80%;">
     <h3><span  style="color:#0A1248;" class="glyphicon glyphicon-book"></span></h3><br/>
    </div>
        <br/> 
     <a href=\''.$row['direcion_ej'].'\' title=\''.$row['nombre_ej'].'\' style="color:#000000;">
     <div class="col-md-10 " style=" word-wrap: break-word;">
        <div class="col-md-12 "> <h4>'.$row['nombre_ej'].'</h4></div>
       <h6> Subido por :   '.$nombre['nombre'].' '.$nombre['apellido_paterno'].' '.$nombre['apellido_materno'].'</h6> </div>
         </a> </div>' ;
  }
   }
}
 ?>

