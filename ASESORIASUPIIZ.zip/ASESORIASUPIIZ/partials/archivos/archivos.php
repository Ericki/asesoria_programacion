
  <?php
session_start();
    if (!isset($_SESSION['usuario']) ) {
    header("Location:index.html");
}else{
    if ($_SESSION['tipo_usuario']!='Administrador' and $_SESSION['tipo_usuario']!='Asesor')  {
    header("Location:redireccion.php");
 }else{
    if ($_SESSION['estado']!= 'Alta')  {
    header("Location:espera.php");
 }
}
}
  ?>



  
      <div class="container"  style="  background-color:#29C5D6;" >
    <div>

           <div class="col-md-6 col-md-offset-3">
            <div class="text-center">
        <form id="datosT" method="post" accept-charset="utf-8">
      <div class="form-group">
      <label for="exampleInputFile">Subir archivo</label>
       <input id="descripcion" name="descripcion" type="text" placeholder="Palbras claves sobre el archivo o descripcion del archivo" class="form-control">
       <br/>
<br/>
        <center><input id="DOC" name="DOC" type="file" class="filestyle" data-buttonName="btn-primary" ></center>
      <p class="help-block">Seleccion un archivo.</p>
      </div>
            <br/>
<br/>
<button id="Subir" name="Subir" type="submit" value="Subir" class="btn btn-primary btn-lg" ;>Subir</button>

       <div class="upload-msg"></div><!--Para mostrar la respuesta del archivo llamado via ajax -->
    </form>
      </div>
        </div>
    </div>
    </div>
<div  class="container ">
<br/>
<br/>
 <button id="todos" name="todos" type="submit" value="todos" onclick="todos()" class="btn btn-primary btn-lg" ;>TODOS</button>
 <button id="aceptados" name="aceptados" type="submit" onclick="aceptados()" value="aceptados" class="btn btn-primary btn-lg" ;>Aceptados</button>
 <button id="espera" name="espera" type="submit" onclick="espera()" value="espera" class="btn btn-primary btn-lg" ;>En espera</button>
 </div>
  <div class="container-fluid">
  <div  class="col-md-12" name="tem" id="tem"  style="
height: 500px;
overflow:scroll;
overflow-x: hidden;
visibility: visible;
" >

  </div>


</div>

   <!-- Button trigger modal -->


<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h4 class="modal-title" id="myModalLabel">Descricion</h4>
      </div>
      <div class="modal-body">
          <div style=""  class="col-md-12 col-md visible-desktop text-center" name="des" id="des" >


    </div>
      </div>
      <div class="modal-footer">

      </div>
    </div>
  </div>
</div>
 <div  class="container ">
    <div class="col-md-6 col-md-offset-3">
            <div class="text-center">
        <form id="BA" name="BA" method="post" accept-charset="utf-8">
      <div class="form-group">
      <label for="exampleInputFile">Buscar archivo</label>
       <input id="Nombrea" name="Nombrea" type="text" placeholder="Nombre del archivo" class="form-control">
       <br/>
<br/>
<button id="Buscar" type="submit" name="Buscar"  <?php echo 'onclick="buscar('.$_SESSION['id'].')"'; ?> value="Buscar" class="btn btn-primary btn-lg" ;>Buscar</button>
    </form>
        </div>
         </div>
</div>
<div class="container-fluid">
  <div  class="col-md-12" name="busqueda" id="busqueda"  style="
height: 200px;
overflow:scroll;
overflow-x: hidden;
visibility: visible;
" >
