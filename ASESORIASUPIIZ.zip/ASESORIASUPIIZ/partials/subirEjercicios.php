<?php
  session_start();
  if (!isset($_SESSION['usuario']) ) {
      header("Location:../index.html");
  }else{
      if ($_SESSION['estado']!= 'Alta')  {
      header("Location:espera.php");
      }
  }
?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Asesorias en linea UPIIZ-IPN</title>

      <!-- Bootstrap Core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
<!-- Bootstrap Core CSS -->
     <link href="../css/menutemario.css" rel="stylesheet">
<!-- Bootstrap Core CSS -->
    <link href="../css/freelancer.min.css" rel="stylesheet">
<!-- Bootstrap Core CSS -->
  
    <link href="../css/tamano.css" rel="stylesheet">
    <!-- Custom Fonts -->
    <link href="../css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
     <script type="text/javascript" src="../js/bootstrap-filestyle.min.js"> </script>
     
     <script type="text/javascript" src="../js/subirEjercicios.js"></script>
     <script type="text/javascript" src="../js/mostrar.js"></script>
    <script type="text/javascript" src="../js/modificarNombre.js"></script>

</head>

<body id="page-top" class="index">

    <!-- Navigation -->
<nav id="mainNav" role="navigation" class="navbar navbar-default navbar-fixed-top navbar-custom" >
  <!-- El logotipo y el icono que despliega el menú se agrupan
       para mostrarlos mejor en los dispositivos móviles -->
  <div class="navbar-header">
     <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Asesorias en línea UPIIZ-IPN</span> Menu <i class="fa fa-bars"></i>
                </button>
                <div><img class="img-responsive" src="../img/UPIIZ.png" style="width: 60px; height: 50px;   position: relative;
                  top: 10px;
                  left: 50px;"></div>
                <a class="navbar-brand responsive" href="#page-top"></a>
    </div>

  <!-- Agrupar los enlaces de navegación, los formularios y cualquier
       otro elemento que se pueda ocultar al minimizar la barra -->
  <div class="collapse navbar-collapse navbar-ex1-collapse">
    <ul class="nav navbar-nav navbar-right">
      <li class="page-scroll">
        <a href="inicioAdministrador.php#perfil/<?php echo $_SESSION['id']; ?>" ><img <?php echo 'src="../php/'.$_SESSION['imagen'].'"';?> style="width: 30px; height: 30px; ">
          <span><?php echo $_SESSION['usuario'];?></span></a>
     </li>
     <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Foro<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><!--<a href="#foro" style=" color:#03225C;">Foro para Java</a>-->
          <a href="inicioAdministrador.php#/foro">Foro para Java</a></li>
          <li role="separator" class="divider"></li>
          <li><a href="#" >Foro para C</a></li>
        </ul>
        </li>
        <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Programar<span class="caret"></span></a>
            <ul class="dropdown-menu">
              <li><a href="#">En Java</a></li>
              <li role="separator" class="divider"></li>
              <li><a href="#">En C</a></li>
            </ul>
        </li>
        <?php if ($_SESSION['tipo_usuario']=='Administrador' || $_SESSION['tipo_usuario']=='Asesor')  {
          echo '<li class="page-scroll">
                  <a href="inicioAdministrador.php#/administrar-usuarios" >Usuarios</a>
                </li>';
        } ?>
    <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Contenido<pan class="caret"></span></a>
          <ul class="dropdown-menu">
          <li>
            <a 
                <?php 

                switch ($_SESSION['tipo_usuario']) {
                  case 'Administrador':
                echo 'href="Supertemario.php"';
                    break;
                  case 'Asesor':
                  echo 'href="Supertemario2.php"';
                    break;
                    case 'Alumno Asesor':
                  echo  'href="temarioalumnoasesor.php"';
                    break;
                    case 'Asesorado':
                   echo 'href="temarioasesorado.php"';
                    break;
                  default:
                    # code...
                    break;
                } 

                ?>   
              >Archivos</a>
          </li>
       <?php if ($_SESSION['tipo_usuario']=='Administrador' || $_SESSION['tipo_usuario']=='Asesor')  {
                    echo '<li role="separator" class="divider"></li>
                      <li class="page-scroll">
                          <a href="reportes.php">Reporte</a>
                      </li>';
                    } ?>
       
        <li role="separator" class="divider"></li>
        <li>
          <a href="multimedia.php">Multimedia</a>
        </li>    
      </ul>
  </li>
    <li class="page-scroll">
       <a href="#chat">Chat</a>
    </li>
   <li class="page-scroll">
      <a href="../php/salir.php">Salir&nbsp;</a>
    </li>
    </div>
</nav>

    <!-- Header -->
    <header style="  background-color: #193248;">
        <div class="container " >

 </div>
</header>

  <div class="container"  style="  background-color:#29C5D6;" >
        <div>
        <div class="col-md-6 col-md-offset-3">
            <div class="text-center">
                  <form enctype="multipart/form-data" method="post"  id="ejercicios" >
                    <div class="form-group">
                        <label for="exampleInputFile">Subir archivo</label>
                        <input type="text" name="nombre" id="nombre" placeholder="Palbras claves sobre el archivo o descripcion del archivo" class="form-control" required ><br>
                    <select name="selectModulo" class="form-control" required>
                      <option selected="selected"> Elija un módulo</option>
                      <option value="1">Módulo 1</option>
                      <option value="2">Módulo 2</option>
                      <option value="3">Módulo 3</option>
                      <option value="4">Módulo 4</option>
                      <option value="5">Módulo 5</option>
                    </select>
                    <br>
                    <center><input type="file" id="archivo" name="archivo" class="filestyle" data-buttonName="btn-primary" required></center><br>
                        </div>
                        <br>
                    <button type="submit"  id="btnSubir" type="submit" class="btn btn-primary btn-lg";>Subir</button>
                    <div class="upload-msg"></div><!--Para mostrar la respuesta del archivo llamado via ajax -->


                  </form>
            </div>
        </div>
        </div>
    </div>

<div class="container">
<br/>
<br/>
 <button id="modulo_1" name="modulo_1" type="submit" value="Módulo 1" onclick="_modulo_1()" class="btn btn-primary btn-lg" ;>Módulo 1</button>
 <button id="modulo_2" name="modulo_2" type="submit" onclick="_modulo_2()" value="Módulo 2" class="btn btn-primary btn-lg" ;>Módulo 2</button>
 <button id="modulo_3" name="modulo_3" type="submit" onclick="_modulo_3()" value="Módulo 3" class="btn btn-primary btn-lg" ;>Módulo 3</button>
 <button id="modulo_4" name="modulo_4" type="submit" onclick="_modulo_4()" value="Módulo 4" class="btn btn-primary btn-lg" ;>Módulo 4</button>
 <button id="modulo_5" name="modulo_5" type="submit" onclick="_modulo_5()" value="Módulo 5" class="btn btn-primary btn-lg" ;>Módulo 5</button>
 </div>
</div>

  <div class="container-fluid">
  <div  class="col-md-12" name="tem" id="tem"  style="
height: 500px;
overflow:scroll;
overflow-x: hidden;
visibility: visible;
" >

  </div>


</div>

   <!-- Button trigger modal -->


<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h4 class="modal-title" id="myModalLabel">Editar nombre</h4>
      </div>
      <div class="modal-body">
          <div style=""  class="col-md-12 col-md visible-desktop text-center" name="des" id="des" >

    </div>
      </div>
      <div class="modal-footer">

      </div>
    </div>
  </div>
</div>


    <!-- Footer -->
    <footer class="text-center">
        <div class="footer-above">
            <div class="container">
                <div class="row">
                    <div class="footer-col col-md-8">
                        <h3>Asesorias en linea UPIIZ-IPN</h3>
                        <p>Plataforma web para asesorías de programación C y Java</p>
                    </div>
                    <div>

                    </div>
                </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-below">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        trabajo terminal 1
                    </div>
                </div>
            </div>
        </div>
    </footer>


   <!-- jQuery -->
    <script src="../js/jquery/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="../js/bootstrap.min.js"></script>
    <!-- Plugin JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <!-- Contact Form JavaScript -->
    <script src="../js/jqBootstrapValidation.js"></script>
    <script src="../js/contact_me.js"></script>
    <!-- Theme JavaScript -->
    <script src="../js/freelancer.min.js"></script><script src="../js/angular.min.js"></script>
    <script src="../js/angular-route.min.js"></script>
    <script src="../js/moment/moment.min.js"></script>
    <script src="../js/moment/angular-moment.js"></script>
    <script src="https://unpkg.com/ng-table@2.0.2/bundles/ng-table.min.js"></script>
    <script src="../js/jquery-3.1.1.min.js"></script>
    <script src="../app/app.js"></script>

</body>

</html>
