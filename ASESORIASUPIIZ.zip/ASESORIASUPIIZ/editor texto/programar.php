<?php
$var1 = $_POST['variable1'];
if (file_exists("./" . $var1)) {
    echo ("EL NOMBRE DE ESTA CARPETA YA EXISTE");
} else {
    mkdir("./" . $var1, 0777);
}

$file = fopen("./" . $var1 . "/compilar.php", "w");


$a = fwrite($file, '
	<?php


  $nombre="";
  foreach(glob("*") as $archivos_carpeta)
    {

$trozos = explode(".", $archivos_carpeta); 
       $extension = end($trozos); 
    if ($extension=="java") {
     system(\'javac \'.$archivos_carpeta.\' > resultado.txt 2> Errores.txt\');
  $nombre= str_replace(".java", "", $archivos_carpeta);
echo \'Compilando..\';

    }

     }

     system(\'java \'.$nombre.\'>> resultado.txt \');
$file = fopen("Errores.txt", "r");
while(!feof($file)) {
echo fgets($file). "<br />";
}
fclose($file);
$file = fopen("resultado.txt", "r");
while(!feof($file)) {
echo fgets($file). "<br />";
}
fclose($file);
?>
');
if (!$a) {
    echo "ERROR ";
} else {
    echo ";) ";
}
?>