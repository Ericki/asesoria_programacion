$(function () {

    function siRespuesta(r) {
        $('#respuesta')
            .html(r); // Mostrar la respuesta del servidor en el div con el id "respuesta"
    }

    function siError(e) {
        alert('Ocurrió un error al realizar la petición: ' + e.statusText);
    }

    function Compila(e) { // compilamos el codigo 
        Compila_1();
        ejecuta();
    }


    function Compila_1(e) { // compilamos el codigo 
        var NombreA = $('#calsep')
            .val();
        var programa = $('#Programa')
            .val();
        var carpeta = $('#Compila')
            .val();


        var parametros = {
            Nombre: NombreA
            , programa: programa
            , carpeta: carpeta
        };


        var post = $.post(
            "compilar.php"
            , parametros
            , siRespuesta
            , 'html'
        );



        post.error(siError);
    }

    function ejecuta(e) { // compilamos el codigo 
        var NombreA = $('#calsep')
            .val();
        var programa = $('#Programa')
            .val();
        var carpeta = $('#Compila')
            .val();


        var parametros = {
            Nombre: NombreA
            , programa: programa
            , carpeta: carpeta
        };


        var post = $.post(
            carpeta+"/compilar.php"
            , parametros
            , siRespuesta
            , 'html'
        );



        post.error(siError);
    }
    

    


   
    $('#Compila')
        .click(Compila); // Registrar evento al boton "Calcular" con la funcion "Compilar"
   

});

