#include <stdio.h>
int main(int argc, const char * argv[])
{
    //CICLOS FOR EN C
    for(int x=2;x<20;x+=2)
    h
        printf("El contador X vale: %d\n",x);
    
    return 0;d
}