﻿public class Caro {
public static void main(String[] args) { 
System.out.println("Hola jijiji juana mensa  mundo");
System.out.println("Hola jijiji juana mensa  mundo");
}
}
