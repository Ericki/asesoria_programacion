<?php
$var1 = $_POST['variable1'];
$var1 =  "1";

if (file_exists("./" . $var1)) {
    echo ("EL NOMBRE DE ESTA CARPETA YA EXISTE");
} else {
    mkdir("./" . $var1, 0777);
}

$file = fopen("./" . $var1 . "/compilar.php", "w");

$a = fwrite($file, '
  <?php
system($var1.\'> resultado.txt 2> Errores.txt\');
$file = fopen("Errores.txt", "r");
while(!feof($file)) {
echo fgets($file). "<br/>";
}
fclose($file);

$file = fopen("resultado.txt", "r");
while(!feof($file)) {
echo fgets($file). "<br/>";
}
fclose($file);
?>
');
if (!$a) {
    echo "ERROR ";
} else {
    echo ";) ";
}
?>