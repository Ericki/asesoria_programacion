<?php
$var1 = $_POST['variable1'];
$nombre_archivo = "HolaMundo.java"; 
$var1 = str_replace("\n", "\r\n", $var1);

    


        if(file_exists("./a4")){
            echo("EL NOMBRE DE ESTA CARPETA YA EXISTE");
        }else{
                mkdir("./a4", 0777);
}

$file = fopen("a4/HolaMundo.java", "w");

	
$a=fwrite($file,$var1);
if(!$a){echo "ERROR ";}else{echo "COMPILADO.. ";}

fclose($file);
system('javac a4/HolaMundo.java >> a4/resultado.txt 2>> a4/Errores.txt');
echo '..';
system('java .a4/HolaMundo >> a4/resultado.txt 2>> a4/Errores.txt');
echo '..';
  /*foreach(glob("a4" . "/*") as $archivos_carpeta)
    {
        echo $archivos_carpeta;
 
        if (is_dir($archivos_carpeta))
        {
            eliminarDir($archivos_carpeta);
        }
        else
        {
            unlink($archivos_carpeta);
        }
    }
 
    rmdir("a4");*/





?>