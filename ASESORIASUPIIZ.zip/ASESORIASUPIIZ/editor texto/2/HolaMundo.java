public class HolaMundo 

 
System.out.println("Hola jijiji adrian ");
return 6
