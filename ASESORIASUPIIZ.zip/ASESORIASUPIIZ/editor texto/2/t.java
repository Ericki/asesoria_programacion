// Clase principal iniciadora del programa ejemplo aprenderaprogramar.com

public class t {

    public static void main (String [ ] args) {
        int x=0,y=0;
        char c = 'c';
        String cadena = "kondenas";
        for(int i = 0; i<100; i++ ){ 
            x = x+i;
            y=x;
            //System.out.println ("f("+i+ ")="+y);
             for(int j = 0; j<100; j++ ){ 
            x = x+i;
            y=x;
            System.out.println ("f("+y+ ")="+cadena);
            
        }      
        }    
        
        
        //Aquí las instrucciones de inicio y control del programa
        System.out.print ("Empezamos ya esta fas");
        System.out.print ("Empezamos ya esta erick hola"); 
        
        //esto es para apoyarte a progrmar 

    } //Cierre del main

} //Cierre de la clased