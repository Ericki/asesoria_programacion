//Programa de asesorias Quinto
// Clase principal iniciadora del programa ejemplo aprenderaprogramar.com
public class Quinto {
public static void main (String [ ] args) {
//Aquí las instrucciones de inicio y control del programa
int x = 0, y = 0;
for(x=0;x<1000;x++){
y=x*x;
System.out.println ("f("+x+")="+y);
}
    
} //Cierre del main
} //Cierre de la clase';