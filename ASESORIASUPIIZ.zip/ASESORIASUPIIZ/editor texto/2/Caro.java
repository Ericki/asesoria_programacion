public class Caro {
public static void main(String[] args) { 
 System.out.println ("Empezamos la ejecución del programa");
}
}

