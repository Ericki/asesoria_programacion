// Clase principal iniciadora del programa ejemplo aprenderaprogramar.com

public class T {

    public static void main (String [ ] args) {

 

        //Aquí las instrucciones de inicio y control del programa

 

        System.out.println ("Empezamos la ejecución como de que no del programa");

 

    } //Cierre del main 

} //Cierre de la clase