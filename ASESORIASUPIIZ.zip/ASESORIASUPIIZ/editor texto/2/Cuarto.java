//Programa de asesorias Cuarto
// Clase principal iniciadora del programa ejemplo aprenderaprogramar.com
public class Cuarto {
public static void main (String [ ] args) {
//Aquí las instrucciones de inicio y control del programa
System.out.println ("Empezamos la ejecución del programa");
System.out.println ("no ma ya sirve");
} //Cierre del main
} //Cierre de la clase';