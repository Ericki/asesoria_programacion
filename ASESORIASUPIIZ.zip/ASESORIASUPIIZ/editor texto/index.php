<html>
    <head>
        <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
        <script type="text/javascript" src="Compilar.js"></script>
        <script src="Editor.js"></script>

    </head>
    <body>
      <div>
<div id="Archivos">
      Aquí se imprimirá la respuesta
</div>
  <div id="Sujerencia">
      Aquí se imprimirá la respuesta
</div>
  <h1> Clase </h1>
 <textarea type="text" id="calsep" ></textarea>
  <h1> nombre del documento </h1>

 <textarea type="text" id="Nombre" ></textarea>
  <h1> codigo </h1>
<textarea type="text" id="Programa"  onkeyup="fAgrega();" ></textarea>
  <button id="Programar" value="1">programar</button>
   <button id="Guardar" value="1">Guardar</button>
      <button id="Compila" value="1">Compilar</button>
  <FORM NAME="formulario" >
<input type='file' name='ARCHIVO' id='ARCHIVO' />
<input type='button' id='botonSubidor' onclick="SubirArchivo()" VALUE='SUBIR' />
</FORM>
<div id="respuesta">
      Aquí se imprimirá la respuesta
</div>
<div id="respuesta1">
      Aquí se imprimirá la respuesta
</div>

    </body>
</html>
