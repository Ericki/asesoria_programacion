<?php
$return         = "Se subio el archivo";
$upload_folder  = '2';
$nombre_archivo = $_FILES['archivo']['name'];
$tipo_archivo   = $_FILES['archivo']['type'];
$tamano_archivo = $_FILES['archivo']['size'];
$tmp_archivo    = $_FILES['archivo']['tmp_name'];
$uploadOk       = 1;
if ($tamano_archivo > 2024288) {
    $return   = "Lo sentimos, el archivo es demasiado grande.  Tamaño máximo admitido: 0.5 MB";
    $uploadOk = 0;
}
$trozos    = explode(".", $nombre_archivo);
$extension = end($trozos);
if ($extension != "java") {
    $return   = "Lo sentimos, ese tipo de archivo no esta permitido solo archivos java";
    $uploadOk = 0;
}
$archivador = $upload_folder . '/' . $nombre_archivo;
if ($uploadOk == 1) {
    if (!move_uploaded_file($tmp_archivo, $archivador)) {
        $return = "Error";
    }
}
echo json_encode($return);
?>