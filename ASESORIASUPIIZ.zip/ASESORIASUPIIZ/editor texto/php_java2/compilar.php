
	<?php
	$Nombre   = $_POST['Nombre'];
$programa = $_POST['programa'];
$carpeta  = $_POST['carpeta'];
if (file_exists("./" . $carpeta)) {
   
} else {
    mkdir("./" . $carpeta, 0777);
}

$programa = str_replace("\n", "\r\n", $programa);
$file     = fopen($carpeta . "/" . $Nombre . ".java", "w");
$a        = fwrite($file, $programa);
if (!$a) {
    echo "ERROR ";
} else {
   
}
$file = fopen("./" . $carpeta . "/compilar.php", "w");


$a = fwrite($file, '
	<?php
$var1 ="'.$Nombre.'";
$carpeta="'.$carpeta.'";
system(\'javac \'.$var1.\'.java > resultado.txt 2> Errores.txt\');
$file = fopen("Errores.txt", "r");
while(!feof($file)) {
echo fgets($file). "";
}
fclose($file);

$file = fopen("resultado.txt", "r");
while(!feof($file)) {
echo fgets($file). "";
}
fclose($file);

system(\'java \'.$var1.\'> resultado.txt 2> Errores.txt\');

$file = fopen("Errores.txt", "r");
while(!feof($file)) {
echo fgets($file). "";
}
fclose($file);

$file = fopen("resultado.txt", "r");
while(!feof($file)) {
echo fgets($file). "";
}
fclose($file);

foreach(glob( "*") as $archivos_carpeta)
    {
      $trozos = explode(".", $archivos_carpeta); 
       $extension = end($trozos); 
    
     unlink($archivos_carpeta);

 
        
    }
    $carpeta = "../".$carpeta;

     rmdir($carpeta);
?>


');
if (!$a) {
    echo "ERROR ";
} else {
  
}

/*$var1 = $_POST['Nombre'];


 foreach(glob( "*") as $archivos_carpeta)
    {
      $trozos = explode(".", $archivos_carpeta); 
       $extension = end($trozos); 
    if ($extension=="class") {
     unlink($archivos_carpeta);

    }
        
    }

system('javac '.$var1.'.java > resultado.txt 2> Errores.txt');
$file = fopen("Errores.txt", "r");
while(!feof($file)) {
echo fgets($file). "<br />";
}
fclose($file);

$file = fopen("resultado.txt", "r");
while(!feof($file)) {
echo fgets($file). "<br />";
}
fclose($file);

system('java '.$var1.'> resultado.txt 2> Errores.txt');

$file = fopen("Errores.txt", "r");
while(!feof($file)) {
echo fgets($file). "<br />";
}
fclose($file);

$file = fopen("resultado.txt", "r");
while(!feof($file)) {
echo fgets($file). "<br />";
}
fclose($file);*/
?>


