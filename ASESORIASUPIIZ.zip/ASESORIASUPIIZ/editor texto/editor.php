<!DOCTYPE html>
<html ng-app="MyApp">
<head>
	<title>
		edit code
	</title>
</head>
<body>
<p>hi</p>
<style type="text/css">
	.ace_editor { height: 300px; }
</style>

<section ng-controller="AceCtrl">

  <div ng-repeat="message in messages"  ng-model="message.text" ng-change="messages.$save(message)" ng-keyup="fAgrega(message.text)"></div>

  <select ng-model="mode" ng-options="m for m in modes" ng-change="modeChanged()"></select>
	<ul>
		<li ng-repeat="message in messages">
			<!-- edit a message -->
			<input ng-model="message.text" ng-change="messages.$save(message)" />
			<!-- delete a message -->
			<button ng-click="messages.$remove(message)">Delete Message</button>
		</li>
	</ul>
	<form ng-submit="addMessage()">
		<input ng-model="newMessageText" />
		<button type="submit">Add Message</button>
	</form>



	<div>
	<div id="Archivos">
				Aquí se imprimirá la respuesta
	</div>
		<div id="Sujerencia">
				Aquí se imprimirá la respuesta
	</div>
		<h1> Clase </h1>
	 <textarea type="text" rows="2"cols="100" id="calsep" > </textarea>
		<h1> nombre del documento </h1>

	 <textarea type="text" id="Nombre" rows="2"cols="100"></textarea>
		<h1> codigo </h1>
	<textarea ng-model="tex" type="text" id= "Programa" class="Programa"  rows="20"cols="100" onkeyup="fAgrega();"></textarea><br>

<div ui-ace="aceOption" ng-model="tex"></div>

		<button id="Programar" value="2" ng-click="programar()">programar</button>
		 <button id="Guardar" value="2" ng-click="Guardar1(tex)">Guardar1</button>
				<button id="Compila" value="2" ng-click="Compila(tex)">Compilar</button>
		<FORM NAME="formulario" >
<input type='file' name='ARCHIVO' id='ARCHIVO' />
<input type='button' id='botonSubidor' ng-click="SubirArchivo()" VALUE='SUBIR' />
</FORM>
	<textarea id="respuesta">
				Aquí se imprimirá la respuesta

</textarea>
</section>
<!-- push a new message onto the array -->
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
<script type="text/javascript" src="bower_components/ace-builds/src-min-noconflict/ace.js"></script>
<script type="text/javascript" src="bower_components/angular/angular.js"></script>
<script type="text/javascript" src="bower_components/angular-ui-ace/ui-ace.js"></script>
<script type="text/javascript" src="bower_components/ace-builds/src-min-noconflict/ext-language_tools.js"></script>
<script src="https://cdn.firebase.com/js/client/2.2.4/firebase.js"></script>
<script src="https://cdn.firebase.com/libs/angularfire/1.2.0/angularfire.min.js"></script>
<script type="text/javascript" src="Compilar.js"></script>
<script src="Editor.js"></script>
<script type="text/javascript" src="app.js"></script>
</body>
</html>
