<?php
session_start();
    if (!isset($_SESSION['usuario']) ) {
    header("Location:../index.html");
}else{
    if ($_SESSION['tipo_usuario']!='Administrador'and $_SESSION['tipo_usuario']!='Asesor'and $_SESSION['tipo_usuario']!='Alumno Asesor') {
    header("Location:redireccion.php");
 }else{
    if ($_SESSION['estado']!= 'Alta')  {
    header("Location:../partials/espera.php");
 }
}
}
$id=$_SESSION['id'];
require('conexion.php');

$respuesta = array();
$s=false;
if ( strcmp($_POST['selectModulo'], "Elija un módulo")!== 0){
	$s= true;
}
if(!empty($_FILES['archivo']['name']) && !empty($_POST['nombre']) && $s)
	{

		$_file = $_FILES['archivo']['name'];
		$_file_size=$_FILES['archivo']['size'];
		$_file_error= $_FILES['archivo']['error'];
		$_file_tmp=$_FILES['archivo']['tmp_name'];
		$_file_type=$_FILES['archivo']['type'];
		$_fileload= false;
		$_nombre= $_POST['nombre'];
		$modulo = $_POST['selectModulo'];
		$band = 0;
		$band2 = 0;
		$consult=0;
		$Invalidos = array("'","+","%","(",")","()",";","/","?","¿","<",">","&","^","~","%");

		$file= str_replace($Invalidos, "",$_file,$fileCont);
		$nombre = str_replace($Invalidos, "",$_nombre,$nomCont); 
		$caracteresMalos=$fileCont+$nomCont;
		

		//si no hay directorio, lo creamos
	   	if(!is_dir("../php/ejercicios/")){
	     	mkdir("../php/ejercicios/", 0777,true);
	   	}

		if ($_file_error>0) {
			$respuesta["estatus"] = 2;
			$respuesta['mensaje'] = "Problemas al cargar la imágen";
			$band=2;
		}
		 if ($_file_size>8388608){
		 	$respuesta["estatus"] = 2;
			$respuesta['mensaje'] = "Exedio el tamaño de archivo permitido";
			$band=3;
		}

		if (!(strpos($_file_type, "pdf"))){
			 $tipo=false;
			 $respuesta["estatus"] = 2;
			 $respuesta['mensaje'] = "Sólo se permiten archivos .pdf";
			 $band=4;
		}

		if ($caracteresMalos != 0) {
			$respuesta["estatus"] = 2;
			$respuesta['mensaje'] = "Caracteres no válidos";
			$band=5;
		}

		$sql2   = "SELECT * FROM ejercicios WHERE nombre_ej =:nombre";
		$resultado=$base->prepare($sql2);
		$resultado->bindValue(":nombre", $nombre);
		$resultado->execute();
		$resul2=$resultado->rowCount();
		if ($resul2 == 0 && $band == 0) {
		
			$filedif = date('Y-m-d').date('H-i-s');
			$ruta = "../php/ejercicios/".$filedif;

			$move_file = move_uploaded_file($_file_tmp, $ruta);


			if (!$move_file) {
				$respuesta["estatus"] = 2;
				$respuesta['mensaje'] = "Error al cargar el archivo";
				$_fileload= true;
			}
				
			if ($_fileload == false ) {
				$consult = 1;
				$sql = "INSERT INTO ejercicios (id_ejercicios,direcion_ej,id_asesor,nombre_ej,modulo)VALUES(null,'$ruta','$id','$nombre',$modulo)";	
				//$base->exec($sql);
				if ($base->query($sql)) {
					$respuesta["estatus"] = 1;
					$respuesta['mensaje'] = "Ejercicio subido exitosamente";
				} else {
					$respuesta["estatus"] = 3;
					$respuesta['mensaje'] = "Error con el archivo";
				}

					//$db = null;
				//$respuesta["estatus"] = 1;
				//$respuesta['mensaje'] = "Usuario Registrado Exitosamente";
			}
			if ($consult==1) {
				$respuesta["estatus"] = 1;
				$respuesta['mensaje'] = "Archivo subido Exitosamente";
			}
		}

		if ($resul2 !=0) {
			$respuesta["estatus"] = 2;
			$respuesta['mensaje'] = "El ejercicio ".$nombre." ya existe, eliga otro archivo";
		}

		
	}else{
		$respuesta["estatus"] = 2;
		$respuesta['mensaje'] = "Faltan datos obligatorios";
	}

	echo json_encode($respuesta);
?>
