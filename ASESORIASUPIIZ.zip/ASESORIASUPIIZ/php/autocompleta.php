﻿<?php
require 'conexion.php';
$sql = $base->prepare('SELECT CONCAT (nombre," ",apellido_paterno," ",apellido_materno) as nom  FROM `usuarios` WHERE 1 ');
$sql->execute();
$resultado = $sql->fetchAll();

$texto = strtolower(trim($_POST["municipio"]));

$sugerencias = array();
foreach ($resultado as $res => $var) {
    if (preg_match('/^(' . $texto . ')/i', $var["nom"])) {
        $sugerencias[] = $var["nom"];
        if (count($sugerencias) > 20) {
            break;
        }
    }
}

if (isset($_GET["modo"]) && $_GET["modo"] != null) {
    $modo = $_GET["modo"];
} else {
    $modo = "json";
}

if ($modo == "ul") {
    if (count($sugerencias) > 0) {
        echo "<ul>\n<li>";
        echo implode("</li>\n<li>", $sugerencias, "</li>\n<li>");
        echo "</li>\n</ul>";
    } else {
        echo "<ul></ul>";
    }
} else {
    if (count($sugerencias) > 0) {
        echo "[ \"";
        echo implode($sugerencias, "\", \"");
        echo "\"]";
    } else {
        echo "[]";
    }
}
