<?php
session_start();
require 'conexion.php';
$link        = str_replace("https://www.youtube.com/watch?v=", "https://www.youtube.com/embed/", $_POST['link']);
$titulo      = $_POST['titulo'];
$descripcion = $_POST['descripcion'];

$sentencia = $base->prepare("INSERT INTO `multimedia` (`id_usuario`, `linkvideo`, `titulo`, `descripcion`, `id_multi`) VALUES (:usuario, :link, :titulo, :descripcion, NULL);");
$sentencia->bindParam(':usuario', $_SESSION['id']);
$sentencia->bindParam(':link', $link);
$sentencia->bindParam(':titulo', $titulo);
$sentencia->bindParam(':descripcion', $descripcion);
$sentencia->execute();
?>