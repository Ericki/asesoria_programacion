
<?php 
$v1 = $_GET['variable1'];
require('conexion.php');
$sql = "DELETE  FROM `ejercicios` WHERE `ejercicios`.`direcion_ej` = :dir";	
	$resultado=$base->prepare($sql);
	$resultado->bindValue(":dir", $v1);
$resultado->execute();


if(file_exists($v1)) 
{ 
if(unlink($v1)) 
	header("Location:../partials/subirEjercicios.php");} 
else
print "Este archivo no existe"; 
	
header("Location:../partials/subirEjercicios.php");
			
?>