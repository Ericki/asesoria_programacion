<?php
namespace ChatApp;



//$link=mysql_connect($host, $usuario, $pass)or die("¡Imposible conectar!");
//mysql_select_db("baseasesorias", $link)or die("Ups!, no se encuentra la BD");

use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

class Chat implements MessageComponentInterface {
    protected $clients;
    private $subscriptions;
    private $users;
    public function __construct() {
        $this->clients = new \SplObjectStorage;
        $this->subscriptions = [];
        $this->users = [];
    }

    public function onOpen(ConnectionInterface $conn) {
        $this->clients->attach($conn);
        $this->users[$conn->resourceId] = $conn;
        }

    public function onMessage(ConnectionInterface $conn, $msg) {
        /*foreach ($this->clients as $client) {
            if ($from !== $client) {

                $client->send($msg);
                  echo "({$msg})\n";
                  $array = json_decode($msg);
                  print_r($array);

            }
        }*/
        $data = json_decode($msg);
       switch ($data->command) {
           case "subscribe":
               $this->subscriptions[$conn->resourceId] = $data->channel;
               echo "({$data->channel})\n";

               break;
           case "message":
               if (isset($this->subscriptions[$conn->resourceId])) {
                   $target = $this->subscriptions[$conn->resourceId];
                   foreach ($this->subscriptions as $id=>$channel) {
                       if ($channel == $target && $id != $conn->resourceId) {
                           $this->users[$id]->send($msg);
                           echo "({$msg})\n";
                       }
                   }
               }
       }//fin switch
    }

    public function onClose(ConnectionInterface $conn) {

        $this->clients->detach($conn);
        unset($this->users[$conn->resourceId]);
               unset($this->subscriptions[$conn->resourceId]);
        echo "Connection {$conn->resourceId} has disconnected\n";
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        echo "An error has occurred: {$e->getMessage()}\n";

        $conn->close();
    }
}
