var seconds = 20; // el tiempo en que se refresca
var divid = "multi"; // el div que quieres actualizar!
var url = "multimedia_1.php"; // el archivo que ira en el div
window.onload = function() {
  refreshdiv();
}

function refreshdiv() {
    var xmlHttp;
    try {
        xmlHttp = new XMLHttpRequest();
    } catch (e) {
        try {
            xmlHttp = new ActiveXObject("Msxml2.XMLHTTP"); // Internet Explorer
        } catch (e) {
            try {
                xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
            } catch (e) {
                alert("Tu explorador no soporta AJAX.");
                return false;
            }
        }
    }
    var timestamp = parseInt(new Date().getTime().toString().substring(0, 10));
    var nocacheurl = url + "?t=" + timestamp;
    xmlHttp.onreadystatechange = function() {
        if (xmlHttp.readyState == 4 && xmlHttp.readyState != null) {
            document.getElementById(divid).innerHTML = xmlHttp.responseText;
            ///setTimeout('refreshdiv()', seconds * 1000);
        }
    }
    xmlHttp.open("GET", nocacheurl, true);
    xmlHttp.send(null);
}



function multimedia() {
    refreshdiv();
    var link = document.getElementById("link").value;
    var titulo = document.getElementById("titulo").value;
    var descripcion = document.getElementById("descripcion").value;
    var mensaje = $("#des");
    var formData = link;
    var parametros = {
        "link": link,
        "titulo": titulo,
        "descripcion": descripcion
    };
    $.ajax({
        data: parametros,
        url: '../php/guardarmultimedia.php',
        type: 'post',
    }).done(function(msg) {
        mensaje.html(msg);
    }).fail(function(jqXHR, textStatus, errorThrown) {
        mensaje.html("Estamos teniendo problemas");
    });
}
