function descriocion(descri)
{  
    var mensaje =$("#des");
        var parametros = {
                "descri" : descri      
        };

        $.ajax({
                data:  parametros,
                url:   '../partials/cambiarNombre.php',
                type:  'post',

        }).done(function(msg){  
            mensaje.html(msg);    
           }).fail( function( jqXHR, textStatus, errorThrown ) {
    mensaje.html("Estamos teniendo problemas");
});
}
function editar(ids)
{  
    var mensaje =$("#des");
        var parametros = {
                "id" : ids          
        };
        $.ajax({
                data:  parametros,
                url:   '../partials/editarNombre.php',
                type:  'post',

        }).done(function(msg){  
            mensaje.html(msg);    
           }).fail( function( jqXHR, textStatus, errorThrown ) {
    mensaje.html("Estamos teniendo problemas");
});
}
function editar1(id)
{ 
    var nomb = document.Edit.nombre.value;
   
    var mensaje =$("#des");
        var parametros = {
                "nomb" : nomb,
                "id": id
        };
        $.ajax({
                data:  parametros,
                url:   '../partials/editarNombre_1.php',
                type:  'post',

        }).done(function(msg){ 
           $(".upload-msg").html(msg);
            window.setTimeout(function() {
            $(".alert-dismissible").fadeTo(500, 0).slideUp(500, function(){
            $(this).remove();
            }); }, 5000);   
           })
}