var test = angular.module("A", []);
test.factory("services", ['$http', function($http) {
  var serviceBase = '../services/'
    var obj = {};
    obj.getCustomers = function(){
        return $http.get(serviceBase + 'customers');
    }
    obj.getUsuarios = function(){
        return $http.get(serviceBase + 'usuarios');
    }
    obj.getCustomer = function(customerID){
        return $http.get(serviceBase + 'customer?id=' + customerID);
    }


    return obj;

}]);

test.controller('TestCtrl', function($scope) {alert('test');});
test.controller('listCtrl', function ($scope, services) {
    services.getCustomers().then(function(data){
        $scope.customers = data.data;
    });
});
test.controller('listUsuariosCtrl', function ($scope, services) {
    services.getUsuarios().then(function(data){
        $scope.customers = data.data;
    });
});
